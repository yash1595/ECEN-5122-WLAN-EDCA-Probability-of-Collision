% BRIEF : This project is the MATLAB simulation of the algorithm mentioned
% in the paper, "Simplified Probabilistic Modelling and Analysis of Enhanced 
% Distributed Coordination Access in IEEE 802.11". This project calculates
% the Probability of collision in 802.11 networks with QoS. This includes
% AC for Voice, Video, best effort and background tasks. Various different
% scenarios have been implemeneted to depict the impact of number of nodes
% in a network on Probability of collisioin as well as the impact by 
% different types of ACs in a network.

clc;
rows=1;                                                                     
cols=2;

load variables                                                             % Loads matrices stored in variables.mat

prompt = 'Enter Matrix name: ';
Minput = input(prompt);
M = Minput;                                                                % Variable matrix is loaded from variables.mat

K = size(M,rows);                                                          % Stores the size of rows in K.
N = size(M,cols);                                                          % Stores the size of columns in N.
CWmax = [0, 16, 32, 64, 128, 256, 512, 1024];                              % CW interval from Minimum to maximum
Y = zeros();                                                               % Initializes Y as an array.

for i=1:size(CWmax,cols)                                                   % Loops through different CW intevervals
    M = Pcoll_CWchange(M,i,CWmax,K);                                       % Alters the CW.
    Pwin_Arr = Pcoll_Calculate(M,K,rows);                                  % Calculates probability of winning as sum of individual Pwin.
    Y(i) = (1-sum(Pwin_Arr,1));                                            % Calculates Probability of a collision.
    fprintf(sprintf('Pcoll=%0.4f\n',(1-sum(Pwin_Arr,1))));                 % Displays the probability of colision.
    M = Minput;                                                                % Replace with original Matrix.
end
    
Pcoll_Plots_CWmax(Y,CWmax,K);                                              % Plots the Probability of collision  VS CW size.


