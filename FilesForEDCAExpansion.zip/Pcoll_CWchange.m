% brief : This function alters the columns of matrix M to provide a
%         different CW.

function M = Pcoll_CWchange(M,i,CWmax,K)                                    
    if (i~=1)                                                              % Excludes the first iteration.
        for j=1:K                                                          % Cycles through each station.
            if (M(j,2) < 9)                                                % If CWmin is less than 9, doubles the CW. 
                M(j,2) = M(j,2)*2;                                         
            else
                M(j,2) = CWmax(i);                                         % If not, the CW is updated.
            end
        end
    end
end