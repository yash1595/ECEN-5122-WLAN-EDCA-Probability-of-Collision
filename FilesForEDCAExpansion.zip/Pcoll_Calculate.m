% brief : This function calculates the Pwin for each station by following
%         the alogorithm from paper title mentioned in the introduction. The
%         algorithm considers, 1. The channel was idle before the first
%         station begins. 2. Only the first station's Pwin is calculated. The array
%         of stations is then rotated to bring a new station to position one to
%         enable Pwin calculation for this new station. The same process continues
%         till all stations' probability of winning has been calculated.

function Pwin_Arr = Pcoll_Calculate(M,K,rows)
Pwin_Arr = zeros(K,1);                                                     % Initializes array to hold the Pwin values.
Summation_Array = zeros(1,K);                                              % Array which stores the sum of AIFSn and CWmin.

    for station=1:K                                                        % Loops through each row of matrix containing the AIFSN and CWmin.
        Final_Array = zeros(K-1,M(1,2));                                   % Predfined array to store the intermediate probabilities.
        for k=1:K
            Summation_Array(k) = M(k,1)+M(k,2);                            % Stores the sum of AIFSn and CWmin.
        end
        
        for n=(M(1,1)+1):Summation_Array(1)                                % Loop from first AIFSn to first sum of AIFSN and CWmin.
            for k=2:K                                                      % Loops through second row till the last one.
                count=0;
                for z=(M(k,1)+1):Summation_Array(k)                        % In the range of AIFSn+1 till Summation of kth AIFSn+CWmin.
                    if z>n                                                 % If the variable is greater than the current AIFSn+1 value.
                        count=count+1;                                     % Increment count by 1.
                    end
                end
                if count>0                                                 % If count is>0, add it to Final Array.
                    Final_Array(k-1,(n-M(1,1)))=count; 
                end
            end
        end

        Summation_after_processing = sum(prod(Final_Array,1));             % Each element within a column is multiplied then the columns are added.

        Product = Product_Of_Columns(M,K);                                 % The product of each AIFSn and corresponding CWmin is taken.

        Pwin = Summation_after_processing/Product;                         % Total Pwin is calculated for station-1.
        Pwin_Arr(station)=Pwin;                                            % This value is stored in Pwin_Arr.
        M=circshift(M,1,rows);                                             % Shifts the station-1 to bottom and last station to the top.

    end
end