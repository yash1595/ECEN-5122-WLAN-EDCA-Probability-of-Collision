% brief : This function plots the Pcollision variation with varying CW
%         values.
function Pcoll_Plots_CWmax(Y,CWmax,K)
    plot(CWmax,Y,'b--o');
    xlabel('CWmax -->');
    ylabel('Pcoll -->');
    title(['Pcollision VS CWmax with ',num2str(K),'-stations']);
end