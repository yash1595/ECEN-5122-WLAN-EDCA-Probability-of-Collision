% brief : This function alters the columns of matrix M to provide a
%         different CW.

function M = Pcoll_CWchange_reverse(M,i,CWmaxRev,K)                                    
    if (i~=1)                                                              % Excludes the first iteration.
        for j=1:K                                                          % Cycles through each station.
            if (M(j,2) == 16)                                                % If CWmin is less than 9, doubles the CW. 
                M(j,2) = 8;
            elseif (M(j,2) == 8)
                M(j,2) = 4;
            else
                M(j,2) = CWmaxRev(i);                                         % If not, the CW is updated.
            end
        end
    end
end