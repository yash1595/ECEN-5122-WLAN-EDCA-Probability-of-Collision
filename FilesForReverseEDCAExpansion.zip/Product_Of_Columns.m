
% Function Definitions
function Product= Product_Of_Columns(M,K)
    Product = 1;
    for i=1:K
        Product = Product*M(i,2);
    end
end

