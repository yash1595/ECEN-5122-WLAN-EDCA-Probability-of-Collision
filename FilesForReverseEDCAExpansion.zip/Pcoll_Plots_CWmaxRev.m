% brief : This function plots the Pcollision variation with varying CW
%         values.
function Pcoll_Plots_CWmaxRev(Y,CWmaxRev,K)
    set(axes, 'xdir','reverse');
    plot((CWmaxRev),Y,'b--o');
    xlabel('<-- CWmaxRev');
    ylabel('Pcoll -->');
    title(['Pcollision VS CWmaxRev with ',num2str(K),'-stations']);
end